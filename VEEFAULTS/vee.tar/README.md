This folder is zipped up into the included vee.tar file.
The purpose is to deploy the essentials needed to get started on a box, these being:
- colored bash prompt with slightly altered directory and time fields so that you can better troubleshoot, read, and know it is you versus another user
- having critical vim settings (eg. search highlighting and 'jj' escaping), without disrupting settings for root, which may be shared in enclaved dev envs
- creating a dir for your user that indicates this deployment was performed, and which keeps your files separated from other uesrs (if sharing root)
